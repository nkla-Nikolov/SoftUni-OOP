﻿using System;

namespace FootballTeamGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
